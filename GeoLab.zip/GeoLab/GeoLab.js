document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.getElementById('prev');
    const nextBtn = document.getElementById('next');

    let currentSlide = 0;

    function showSlide(n) {
        slides.forEach((slide) => {
            slide.classList.remove('active');
        });

        slides[n].classList.add('active');

        updateDotColors(n);
    }

    function updateDotColors(n) {
        dots.forEach((dot, index) => {
            if (index === n) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            showSlide(index);
        });
    });

    prevBtn.addEventListener('click', () => {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(currentSlide);
    });

    nextBtn.addEventListener('click', () => {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    });

    // Initially show the first slide
    showSlide(0);

    // Add event listeners for mouse enter and leave to zoom effect
    slides.forEach(slide => {
        slide.addEventListener('mouseenter', () => {
            slide.querySelector('img').style.transform = 'scale(1.1)';
        });

        slide.addEventListener('mouseleave', () => {
            slide.querySelector('img').style.transform = 'scale(1)';
        });
    });
});

let currentIndex = 0;
const slides = document.querySelectorAll('.new-slide-content');
const totalSlides = slides.length;
const slideTrack = document.querySelector('.new-slide-track');

function showSlide(index) {
    const slideWidth = slides[0].clientWidth;
    slideTrack.style.transform = `translateX(${-index * slideWidth}px)`;
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % totalSlides;
    showSlide(currentIndex);
}

function prevSlide() {
    currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
    showSlide(currentIndex);
}

setInterval(nextSlide, 3000); 
window.addEventListener('resize', () => {
    showSlide(currentIndex);
});